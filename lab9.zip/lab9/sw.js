var mycache = "mycache";
var assests = [
"/",
"/index.html",
"/start.js",
"/sw.js",
"/icons/logo.png",
"/manifest.json",
];
//function to fetch the github details
async function fetchGH() {
const response = await fetch('https://api.github.com/users/Divya-M-24');
return await response.text()

}
self.addEventListener('install', _event => {
// console.log('inside the install', _event);
});

self.addEventListener('activate', _event => {
// console.log('inside the activate', _event);
});
self.addEventListener('fetch', async (event) => {
const res = await fetchGH();
console.log("RES is: ",res);
// console.log('inside the fetched', event);
});